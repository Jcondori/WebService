create FUNCTION "F_SYSDATE" RETURN DATE IS
    v_sysdate  date;
BEGIN
    SELECT TO_CHAR(current_timestamp,'DD/MM/YYYY') INTO v_sysdate FROM dual;
    RETURN v_sysdate;
END f_sysdate;
/

