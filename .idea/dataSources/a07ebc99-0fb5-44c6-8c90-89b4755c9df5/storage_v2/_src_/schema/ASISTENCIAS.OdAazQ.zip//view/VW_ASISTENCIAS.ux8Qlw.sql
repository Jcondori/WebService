create view VW_ASISTENCIAS as
  SELECT
    asistencia.cod_as,
    alternancia.codalt,
    TO_CHAR(asistencia.fch_dia,'dd/MON/yyyy') AS fch_dia,
    TO_CHAR(asistencia.hora_ent1,'HH:MI AM') AS hora_ent1,
    TO_CHAR(asistencia.hora_sal1,'HH:MI AM') AS hora_sal1,
    TO_CHAR(asistencia.hora_ent2,'HH:MI AM') AS hora_ent2,
    TO_CHAR(asistencia.hora_sal2,'HH:MI AM') AS hora_sal2,
    TO_CHAR(asistencia.fch_dia,'Day','NLS_DATE_LANGUAGE=SPANISH') AS dia,
    asistencia.codact,
    actividades.nomact,
    cultivos.nomcul,
    asistencia.codcul,
    asistencia.dendia,
    (CASE asistencia.dendia
            WHEN 'A'   THEN 'ASISTENCIA'
            WHEN 'I'   THEN 'FALTA'
            WHEN 'J'   THEN 'JUSTIFICACIÓN'
            WHEN 'F'   THEN 'FERIADO'
        END
    ) AS denominacion,
    asistencia.justificacion,
    alternancia.estalt,
    alternancia_detalle.cod_alum
FROM  asistencia
    INNER JOIN alternancia_detalle ON asistencia.codaltdet = alternancia_detalle.codaltdet
    INNER JOIN alternancia ON alternancia_detalle.codalt = alternancia.codalt
    LEFT OUTER JOIN actividades ON asistencia.codact = actividades.codact
    LEFT OUTER JOIN cultivos ON cultivos.codcul = asistencia.codcul
ORDER BY asistencia.FCH_DIA
/

