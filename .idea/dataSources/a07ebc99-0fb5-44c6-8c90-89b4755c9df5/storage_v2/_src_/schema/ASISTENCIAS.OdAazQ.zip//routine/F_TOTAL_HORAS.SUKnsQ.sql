create FUNCTION "F_TOTAL_HORAS" (
    codigo_alumno   IN NUMBER,
    mod_abr         IN VARCHAR2
) RETURN NUMBER IS
    total_horas   NUMBER;
BEGIN
    SELECT
        SUM(
            CASE
                WHEN round( (TO_DATE(
                    TO_CHAR(asistencia.hora_sal1,'DD/MM/YYYY HH24:MI:SS'),
                    'DD/MM/YYYY HH24:MI:SS'
                ) - TO_DATE(
                    TO_CHAR(asistencia.hora_ent1,'DD/MM/YYYY HH24:MI:SS'),
                    'DD/MM/YYYY HH24:MI:SS'
                ) ) * 24) > 8 THEN 8
                ELSE round( (TO_DATE(
                    TO_CHAR(asistencia.hora_sal1,'DD/MM/YYYY HH24:MI:SS'),
                    'DD/MM/YYYY HH24:MI:SS'
                ) - TO_DATE(
                    TO_CHAR(asistencia.hora_ent1,'DD/MM/YYYY HH24:MI:SS'),
                    'DD/MM/YYYY HH24:MI:SS'
                ) ) * 24)
            END
        )
    INTO
        total_horas
    FROM
        asistencia
        INNER JOIN alternancia_detalle ON alternancia_detalle.codaltdet = asistencia.codaltdet
        INNER JOIN alternancia ON alternancia_detalle.codalt = alternancia.codalt
        INNER JOIN aula ON aula.cod_aula = alternancia.cod_aula
        INNER JOIN carrera ON carrera.cod_car = aula.cod_car
    WHERE
            alternancia_detalle.cod_alum = codigo_alumno
        AND
            carrera.abrmod = mod_abr;

    IF
        total_horas >= 0
    THEN
        RETURN total_horas;
    ELSE
        RETURN 0;
    END IF;
END f_total_horas;
/

