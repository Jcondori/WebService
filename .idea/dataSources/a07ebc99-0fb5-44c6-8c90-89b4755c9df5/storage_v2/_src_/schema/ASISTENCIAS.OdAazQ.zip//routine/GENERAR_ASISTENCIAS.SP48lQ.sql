create PROCEDURE "GENERAR_ASISTENCIAS" 
(
    FechaInicio IN DATE,
    CodAlternanciaDetalle IN VARCHAR2
) AS
BEGIN
    declare
        fecha date;
        begin
            FOR i IN 0 .. 5 LOOP
                fecha := FechaInicio + i; -- Para que suba automaticamente trabajar con "fecha"
                Insert into ASISTENCIA (CODALTDET,FCH_DIA) VALUES (CodAlternanciaDetalle,fecha);
            END LOOP;

            FOR i IN 7 .. 12 LOOP
                fecha := FechaInicio + i; -- Para que suba automaticamente trabajar con "fecha"
                --Procedimiento
                Insert into ASISTENCIA (CODALTDET,FCH_DIA) VALUES (CodAlternanciaDetalle,fecha);
            END LOOP;
        EXCEPTION
            WHEN OTHERS
                THEN
                    dbms_output.put_line(SQLERRM);
    end;
END GENERAR_ASISTENCIAS;
/

