create view VW_ALTERNANCIAS_PROFESOR as
  SELECT DISTINCT
    alternancia.codalt,
    alternancia_detalle.codalt as codAlternancia,
    TO_CHAR(pra1.fch_ini_prac,'dd/MON/yyyy','NLS_DATE_LANGUAGE=SPANISH') AS fch_ini_prac,
    TO_CHAR(pra2.fch_fin_prac,'dd/MON/yyyy','NLS_DATE_LANGUAGE=SPANISH') AS fch_fin_prac,
    alumno.cod_alum,
    (nucleos.codnt || ' - ' || aula.SEM_AULA) AS codnt,
    nucleos.nomnuc,
    carrera.abrmod
FROM
    alternancia
    INNER JOIN practicas pra1 ON pra1.cod_prac = alternancia.codpra1
    INNER JOIN practicas pra2 ON pra2.cod_prac = alternancia.codpra2
    INNER JOIN aula ON aula.cod_aula = alternancia.cod_aula
    INNER JOIN grupo ON grupo.cod_aula = aula.cod_aula
    INNER JOIN alumno ON grupo.cod_alum = alumno.cod_alum
    INNER JOIN nucleos ON nucleos.codnuc = alternancia.codnuc
    INNER JOIN carrera ON carrera.cod_car = aula.cod_car
    LEFT OUTER JOIN ALTERNANCIA_DETALLE ON ALTERNANCIA_DETALLE.CODALT = alternancia.CODALT
ORDER BY alternancia.CODALT DESC
/

