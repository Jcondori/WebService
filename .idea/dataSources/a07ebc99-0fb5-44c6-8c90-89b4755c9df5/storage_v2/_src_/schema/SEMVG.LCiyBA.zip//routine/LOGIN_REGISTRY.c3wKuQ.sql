create PROCEDURE "LOGIN_REGISTRY" ( CODIGO IN VARCHAR2 , ALTERNANCIA IN NUMBER)
IS
NombreAlumno varchar2(230);
begin
    NombreAlumno := null;
    Select (NOM_ALUM || ' ' || APE_ALUM) into NombreAlumno from alumno where COD_ALUM = CODIGO;
    if NombreAlumno is not null then
        Insert into AUDITORIA (USUARIO,EVENTO,CODALT,FECHA) VALUES (NombreAlumno,'Inicio Sesión',ALTERNANCIA,CURRENT_TIMESTAMP);
    end if;
END;
/

