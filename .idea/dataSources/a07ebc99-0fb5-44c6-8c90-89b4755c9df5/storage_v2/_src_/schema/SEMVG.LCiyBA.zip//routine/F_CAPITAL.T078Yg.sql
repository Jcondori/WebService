create FUNCTION "F_CAPITAL" ( Text Varchar2 ) Return Varchar2 Is
    Textlocal   Varchar2(250);
Begin
    Select
        Upper(Substr(Text,0,1) ) || Lower(Substr(Text,2,Length(Text))) Into Textlocal From Dual;
    Return Textlocal;
End F_Capital;
/

