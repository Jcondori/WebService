create view VW_ALTERNANCIAS_ACTIVAS as
  SELECT DISTINCT
    alternancia.codalt,
    alternancia_detalle.codalt as codAlternancia,
    TO_CHAR(pra1.fch_ini_prac,'DD/MM/YYYY') AS fch_ini_prac,
    TO_CHAR(pra2.fch_fin_prac,'DD/MM/YYYY') AS fch_fin_prac,
    nucleos.codnt,
    nucleos.nomnuc,
    carrera.name_car,
    aula.sem_aula,
    aula.sec_aula,
    alternancia.estalt,
    aula.cod_aula,
    (CASE
            WHEN evaluacion_historial.codalt IS NULL THEN 'NO'
            ELSE 'SI'
    END) AS eval
FROM
    alternancia
    LEFT JOIN alternancia_detalle ON alternancia_detalle.codalt = alternancia.codalt
    INNER JOIN practicas pra1 ON pra1.cod_prac = alternancia.codpra1
    INNER JOIN practicas pra2 ON pra2.cod_prac = alternancia.codpra2
    INNER JOIN aula ON aula.cod_aula = alternancia.cod_aula
    INNER JOIN nucleos ON nucleos.codnuc = alternancia.codnuc
    INNER JOIN carrera ON nucleos.cod_car = carrera.cod_car
    LEFT OUTER JOIN evaluacion_historial ON evaluacion_historial.codalt = alternancia.codalt
ORDER BY alternancia.codalt ASC
/

