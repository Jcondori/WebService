create PROCEDURE "DESBLOQUEAR_ALUMNOS_AULAS" 
(
  CodigoAula IN VARCHAR2
) AS 
BEGIN
    declare
    cursor Lista is
        SELECT Alumno.Cod_Alum FROM ALUMNO INNER JOIN Grupo ON Alumno.Cod_Alum=Grupo.Cod_Alum INNER JOIN Aula ON Grupo.Cod_Aula=Aula.Cod_Aula WHERE Aula.Cod_Aula = CodigoAula;
    begin
        for item in Lista loop
            Update Alumno set Alumno.Bloalum = 'true' where Alumno.Cod_Alum = item.Cod_Alum;
        end loop;
    EXCEPTION
        WHEN OTHERS
            THEN
            dbms_output.put_line(SQLERRM);
    end; 
END DESBLOQUEAR_ALUMNOS_AULAS;
/

