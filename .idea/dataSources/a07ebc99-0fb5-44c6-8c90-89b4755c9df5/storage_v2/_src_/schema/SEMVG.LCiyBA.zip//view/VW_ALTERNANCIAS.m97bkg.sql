create view VW_ALTERNANCIAS as
  SELECT DISTINCT
    alternancia.codalt,
    TO_CHAR(pra1.fch_ini_prac,'DD/MM/YYYY') AS fch_ini_prac,
    TO_CHAR(pra2.fch_fin_prac,'DD/MM/YYYY') AS fch_fin_prac,
    nucleos.codnt,
    nucleos.nomnuc,
    carrera.name_car,
    aula.sem_aula,
    aula.sec_aula,
    alternancia.estalt,
        CASE
            WHEN alternancia_detalle.codalt IS NULL THEN 0
            ELSE 1
        END
    AS activo
FROM
    alternancia
    INNER JOIN practicas pra1 ON pra1.cod_prac = alternancia.codpra1
    INNER JOIN practicas pra2 ON pra2.cod_prac = alternancia.codpra2
    INNER JOIN aula ON aula.cod_aula = alternancia.cod_aula
    INNER JOIN nucleos ON nucleos.codnuc = alternancia.codnuc
    INNER JOIN carrera ON nucleos.cod_car = carrera.cod_car
    LEFT OUTER JOIN alternancia_detalle ON alternancia_detalle.codalt = alternancia.codalt
ORDER BY alternancia.codalt ASC
/

