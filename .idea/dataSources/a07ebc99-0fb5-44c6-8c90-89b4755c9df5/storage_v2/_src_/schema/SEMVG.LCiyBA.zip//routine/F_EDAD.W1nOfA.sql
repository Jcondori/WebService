create FUNCTION "F_EDAD" ( CodAlumno Varchar2 ) Return number Is
    Edad number;
Begin
    Select trunc(months_between(F_SYSDATE, to_char(FCH_NAC_ALUM,'dd/mm/yyyy'))/12) INTO Edad from Alumno where COD_ALUM = CodAlumno;
    Return Edad;
End F_EDAD;
/

